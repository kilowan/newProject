<?php
session_start();
?>
<?php
$table='';
$table=$table.'
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
		"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>Agregando Empleado</title>
				<LINK REL=StyleSheet HREF="formato.css" TYPE="text/css" MEDIA=screen>
				<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			</head>
		<body>
			<div class="cabecera">
				<div class="mensaje">
					<p>Añadiendo empleado</p>
				</div>
				<div class="Logo">
					<a href="logout.php">
						<img class="cierra" src="shutdown.png" alt="Cerrar sesión" />
					</a>
				</div><br/>
			</div><br/>
			<div class="cuerpo">';
if (isset($_SESSION['loggedin']) && $_SESSION['tipo']=='Admin')
{
	$table=$table.'
	<form class="nuevoemp" action="rellemp.php" method="post">
		<h1>Hoja del nuevo empleado:</h1><br />
		<label>DNI:</label>
		<input type="text" name="dni" required><br />
		<label>Nombre:</label>
		<input type="text" name="nombre" required><br />
		<label>Primer Apellido:</label>
		<input type="text" name="apellido1" required><br />
		<label>Segundo Apellido:</label>
		<input type="text" name="apellido2" ><br />
		<label>Contraseña:</label>
		<input type="password" name="pass" required><br />
		<p> ¿Que tipo de empleado es?:</p>
		<p>
			<select name="tipo" required>
				<option value="Limpiador">Un limpiador</option>
				<option value="Encargado">Un encargado</option>
				<option value="Tecnico">Un tecnico</option>
				<option value="Admin">Un administrador</option>
				<option value="Temporal">Uno temporal</option>
				<option value="Otro">Otro tipo aún no definido</option>
			</select>
		</p>
		<input type="submit" name="Submit" value="Añadir empleado">
		</form><br/>';
}
else
{
	$table=$table.'<div class="respuesta"><p>Esta página solo esta disponible para administradores</p><p><a href=\'login.html\'>Login</a></p></div>';
}
$table=$table.'
			</div>
			<div class="Pie">
				<p>Trabajo realizado por Jose Javier Valero Fuentes y Juan Francisco Navarro Ramiro para el curso de ASIR 2º X</p>
			</div>
		</body>
	</html>';
echo $table;
mysqli_close($conexion);
?>