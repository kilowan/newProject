<?php
session_start();
?>

<?php
//Conexion inicial
$host_db = "localhost";
$user_db = "Ad";
$pass_db = "1234";
$db_name = "Fabrica";
$tbl_name = "Empleados";
$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);

//compaobación de conexion DB
if ($conexion->connect_error) {
 die("La conexión falló: " . $conexion->connect_error);
}
else
{
	//variables usuario
	$username = $_POST['username'];
	$password = MD5($_POST['password']);
	
	//Comprobación usuario
 	$sql = "SELECT * FROM $tbl_name WHERE dni = '$username' and password = '$password'";
	$result = $conexion->query($sql);
	//inicio html
	$table='';
	$table=$table.'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
		"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>Empleado</title>
				<LINK REL=StyleSheet HREF="formato.css" TYPE="text/css" MEDIA=screen>
				<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			</head>
		<body>';
	//Comprobación usuario (II)
	if (mysqli_num_rows($result)>0) {
		$_SESSION['loggedin'] = true;
		$_SESSION['username'] = $username;
		$_SESSION['start'] = time();
		$_SESSION['expire'] = $_SESSION['start'] + (5 * 60);
		$datos = $conexion->query("SELECT tipo, nombre, apellido1, apellido2 FROM $tbl_name WHERE dni = '$username'");
		//Extraer tipo, nombre y apellidos
		while($fila = mysqli_fetch_assoc($datos))
		{
			$tipos=$fila['tipo'];
			$_SESSION['tipo']=$fila['tipo'];
			$nombreCom=$fila['nombre']." ".$fila['apellido1']." ".$fila['apellido2'];
			$nombre=$fila['nombre'];
		}
		//Mensaje de bienvenida
		$table=$table.'
		<div class="cabecera">
			<p class="mensaje">Bienvenido'.' '.$nombreCom.'<p>
			<div class="Logo">
				<a href="logout.php">
					<img class="cierra" src="shutdown.png" alt="Cerrar sesión" />
				</a>
			</div>
		 <div class="opciones">';
		//Comprobación del tipo de empleado
		//Si es admin
		if($tipos=='Admin')
		{	//adicion boton crear parte	(html)
			$table=$table.'
				<a class="link" href="createparte.php">Crear parte</a>';
			$con = $conexion->query("select P.id_part, P.inf_part, P.pieza, E.nombre, E.id
			from parte P, Empleados E
			where P.emp_crea=E.id and resuelto='0' group by P.id_part, P.inf_part, E.nombre, E.id order by P.id_part asc");
			$pie = $conexion->query("SELECT pieza FROM parte");
			//comprobacion de partes creados (si los hay)
			if(mysqli_num_rows($con)>0)
			{	
				//adicion boton ver parte (html)
				$table=$table.'&nbsp'.'<a class="link" href="partead.php">Ver partes</a>';
			}
			if(mysqli_num_rows($pie)>0)
			{
			// boton de ver las piezas afectadas
			$table=$table.'&nbsp'.'<a class="link" href="piezas.php">Ver piezas</a>';
			}
			// boton de agregar empleado
			$table=$table.'&nbsp'.'
				<a class="link" href="agregaremp.php">Agregar empleado</a>';
			//boton de borrar empleados
			$table=$table.'&nbsp'.'
			<a class="link" href="listaemp.php">Lista empleados</a>';
			//Mostrar partes resueltos por cada tecnico
			$part = $conexion->query("SELECT * FROM parte WHERE resuelto=1");
			if(mysqli_num_rows($part)>0)
			{
				$table=$table.'&nbsp'.'
				<a class="link" href="ranking.php">Ranking</a>'.'&nbsp'.'
				<a class="link" href="Tiempo_medio.php">Tiempo  resolucion medio</a>';
			}
			$table=$table.'</div>';
		}
		//si es un tecnico
		elseif($tipos=='Tecnico')
		{	$con = $conexion->query("select P.id_part, P.inf_part, P.pieza, E.nombre, E.id 
			from parte P, Empleados E 
			where P.emp_crea=E.id and resuelto='0' and P.not_tec is null group by P.id_part, P.inf_part, E.nombre, E.id order by P.id_part asc");
			$con2 = $conexion->query("select P.id_part, P.inf_part, P.pieza, E.nombre, E.id 
			from parte P, Empleados E 
			where P.emp_crea=E.id and resuelto='0' and P.nom_tec='$nombreCom' group by P.id_part, P.inf_part, E.nombre, E.id order by P.id_part asc");
			$pie = $conexion->query("SELECT pieza FROM parte");
			if(mysqli_num_rows($pie)>0)
			{
			// boton de ver las piezas afectadas
			$table=$table.'
				<a class="link" href="piezas.php">Ver piezas</a>';
			}
			//comprobación partes existentes no cerrados
			if(mysqli_num_rows($con)>0 or mysqli_num_rows($con2)>0)		
			{
				$table=$table.'&nbsp'.'<a class="link" href="partetec.php">Ver partes</a></div>';
			}
		}
		//si no es un admin ni tecnico
		else
		{
			//adicion boton crear parte	(html)
			$table=$table.'<a class="link" href="createparte.php">Crear parte</a>';
			$con = $conexion->query("SELECT * FROM parte WHERE oculto=0 AND emp_crea = (SELECT id FROM Empleados WHERE dni = '$username')");
			//comprobacion de partes creados (si los hay)
			if(mysqli_num_rows($con)>0)
			{	
				//adicion boton ver parte (html)
				$table=$table.'&nbsp'.'<a class="link" href="modpartemp.php">Ver parte</a>';
			}
			$table=$table.'</div>';
		}
	}else{
		//si no existe el usuario o su contraseña esta mal
		$table=$table.'
		</div>
		<div class="cuerpo">
			<div class="respuesta">
				<p>Username o Password estan incorrectos.</p>
				<p><a href="login.html">Volver a Intentarlo</a></p>
			</div>
		</div>';
	}

//insercion variable con codigo html
$table=$table.'</div>
		<div class="Pie">
			<p>Trabajo realizado por Jose Javier Valero Fuentes y Juan Francisco Navarro Ramiro para el curso de ASIR 2º X</p>
		</div>
	</body>
</html>';
echo $table;
}
 mysqli_close($conexion);
 ?>