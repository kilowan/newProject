<?php
session_start();
?>
<?php
$table='';
$table=$table.'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
		"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>Empleado</title>
				<link rel="stylesheet" type="text/css" href="formato.css" media="screen" />
				<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			</head>
		<body>
		<div class="cabecera">
				<div class="mensaje">
					<p>Partes creados por ti</p>
				</div>
				<div class="Logo">
					<a href="logout.php">
						<img class="cierra" src="shutdown.png" alt="Cerrar sesión" />
					</a>
				</div>
		</div>
		<div class="cuerpo">';
if (isset($_SESSION['loggedin']))
{
	$host_db = "localhost";
	$user_db = "Ad";
	$pass_db = "1234";
	$db_name = "Fabrica";
	$name=$_SESSION['username'];
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	$con = $conexion->query("select P.resuelto, P.id_part, P.fecha_hora_creacion, P.inf_part, P.fecha_resolucion, P.hora_resolucion, P.not_tec, P.pieza
	from parte P, Empleados E
	where E.dni='$name' and E.id=P.emp_crea and P.oculto=0");
	$table=$table.'<table><tr>
	<th>Numero de parte</th>
	<th>Fecha de creación</th>
	<th>Información del parte</th>
	<th>Piezas afectadas</th>
	<th>Notas del técnico</th>
	<th>Tecnico a cargo</th>
	<th>Fecha de resolución</th>
	<th>Hora de resolución</th></tr>';
	while($fila = mysqli_fetch_array($con, MYSQLI_ASSOC))
	{
		$table=$table.'<tr><td>';
		$table=$table.$fila['id_part'];
		$id=$fila['id_part'];
		$table=$table.'</td><td>';
		$table=$table.$fila['fecha_hora_creacion'];
		$table=$table.'</td><td>';
		$table=$table.$fila['inf_part'];
		$table=$table.'</td><td>';
		$table=$table.$fila['pieza'];
		$table=$table.'</td><td>';
		$table=$table.$fila['not_tec'];
		$table=$table.'</td><td>';
		$nom = $conexion->query("select E.nombre, E.apellido1, E.apellido2 from Empleados E, parte P where E.id=P.tec_res and id_part=$id");
		if(mysqli_num_rows($nom)>0)
		{
			while($row = mysqli_fetch_array($nom, MYSQLI_ASSOC))
			{
				$name='';
				$name=$name.$row['nombre'].' '.$row['apellido1'].' '.$row['apellido2'];
			}
			$table=$table.$name;
			$table=$table.'</td><td>';
			$table=$table.$fila['fecha_resolucion'];
			$table=$table.'</td><td>';
			$table=$table.$fila['hora_resolucion'];
		}
		else
		{
			$table=$table.'--';
			$table=$table.'</td><td>';
			$table=$table.'--';
			$table=$table.'</td><td>';
			$table=$table.'--';
		}
		if($fila['resuelto']==0 && $fila['not_tec']=='')
	 	{
			$table=$table.'</td><td>';
			$table=$table.'<form action="deleteparte.php" method="post">';
			$table=$table.'<p><input type="hidden" name="id" value="';
			$table=$table.$id;
			$table=$table.'">';
			$table=$table.'<input type="submit" value="Eliminar"></p>';
			$table=$table.'</form>';
		}
		elseif($fila['resuelto']==1)
		{
			$table=$table.'</td><td>';
			$table=$table.'<form action="hideparte.php" method="post">';
			$table=$table.'<p><input type="hidden" name="id" value="';
			$table=$table.$id;
			$table=$table.'">';
			$table=$table.'<input type="submit" value="Ocultar"></p>';
			$table=$table.'</form>';
		}
		$table=$table.'</td></tr>';
	}
	$table=$table.'</table>';
}
else
{
	$table=$table.'<div class="respuesta"><p>Esta página solo esta disponible para empleados</p><p><a href=\'login.html\'>Login</a></p></div>';
}
$table=$table.'
		</div>
		<div class="Pie">
			<p>Trabajo realizado por Jose Javier Valero Fuentes y Juan Francisco Navarro Ramiro para el curso de ASIR 2º X</p>
		</div>
	</body>
</html>';
echo $table;
mysqli_close($conexion);
?>