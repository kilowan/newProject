<?php
session_start();
?>

<?php
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
		"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>Parte creado</title>
				<link rel="stylesheet" type="text/css" href="formato.css" media="screen" />
				<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			</head>
		<body>
		<div class="cabecera">
				<div class="mensaje">
					<p>Parte Creado</p>
				</div>
				<div class="Logo">
					<a href="logout.php">
						<img class="cierra" src="shutdown.png" alt="Cerrar sesión" />
					</a>
				</div>
		</div>
		<div class="cuerpo">
			<div  class="respuesta">';
if (isset($_SESSION['loggedin']))
{
	$host_db = "localhost";
	$user_db = "Ad";
	$pass_db = "1234";
	$db_name = "Fabrica";
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	$username = $_SESSION['username'];
	$pieza = $_POST['pieza'];
	$descripcion = $_POST['descripcion'];
	$sql = "SELECT id FROM Empleados WHERE dni = '$username'";
	$result = $conexion->query($sql);
	$id = $conexion->query("SELECT id FROM Empleados WHERE dni = '$username'");
	while($fila = mysqli_fetch_assoc($id))
	{
		$num_id=$fila['id'];
	}		
	if($pieza!="--")
	{	
		$consulta = "insert into parte (emp_crea, resuelto, inf_part , pieza)
		values ($num_id, 0, '$descripcion', '$pieza')";
		$result2 = $conexion->query($consulta);
	}
	else
	{
		$consulta = "insert into parte (emp_crea, resuelto, inf_part)
		values ($num_id, 0, '$descripcion')";
		$result2 = $conexion->query($consulta);
	}
	echo '<p>Gracias por notificarnos el error, se le asignara un tecnico lo antes posible</p>';
}
else
{
	echo '<p>Esta página solo esta disponible para empleados</p>';
	echo '<a href="login.html">Login</a>';
}
echo '
			</div>
		</div>
		<div class="Pie">
			<p>Trabajo realizado por Jose Javier Valero Fuentes y Juan Francisco Navarro Ramiro para el curso de ASIR 2º X</p>
		</div>
	</body>
</html>';
mysqli_close($conexion);
?>
