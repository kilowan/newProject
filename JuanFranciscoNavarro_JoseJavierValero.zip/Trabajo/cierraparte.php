<?php
session_start();
?>
<?php
$table='';
$table=$table.'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
		"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>Parte cerrado</title>
				<LINK REL=StyleSheet HREF="formato.css" TYPE="text/css" MEDIA=screen>
				<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			</head>
		<body>
		<div class="cabecera">
			<div class="mensaje">
				<p>Cerrando parte</p>
			</div>
			<div class="Logo">
				<a href="logout.php">
					<img class="cierra" src="shutdown.png" alt="Cerrar sesión" />
				</a>
			</div><br/>
		</div><br/>
		<div class="cuerpo">
			<div  class="respuesta">';
if (isset($_SESSION['loggedin']))
{
	$host_db = "localhost";
	$user_db = "Ad";
	$pass_db = "1234";
	$db_name = "Fabrica";
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	$username= $_SESSION['username'];
	$id=$_POST['id'];
	$nota=$_POST['not_tec'];
	$piezas=$_POST['piezas'];
	$note = $conexion->query("select not_tec from parte where id_part=$id");
	$name = $conexion->query("select id, nombre, apellido1, apellido2 from Empleados where dni='$username'");
	//extrae id y nombre de empleado
	while($fila = mysqli_fetch_assoc($name))
	{
		$nombre_tecnico=$fila['nombre']." ".$fila['apellido1']." ".$fila['apellido2'];
		$identi=$fila['id'];
	}
	while($row = mysqli_fetch_assoc($note))
	{
		$texto=$row['not_tec'];
		if($texto!="")
		{
			$texto=$texto.'<br />
			Actualización:<br />';
			$texto=$texto.$nota;
		}
		else
		{
			$texto=$nota;
		}
	}
	if($piezas=='--')
	{
		$con = $conexion->query("UPDATE parte SET nom_tec = '$nombre_tecnico', fecha_resolucion = CURRENT_DATE(), hora_resolucion = CURRENT_TIME(), not_tec = '$texto', resuelto = 1, tec_res = $identi  WHERE id_part = $id");
	}
	else
	{
		$con = $conexion->query("UPDATE parte SET pieza= '$piezas', nom_tec = '$nombre_tecnico', fecha_resolucion = CURRENT_DATE(), hora_resolucion = CURRENT_TIME(), not_tec = '$texto', resuelto = 1, tec_res = $identi  WHERE id_part = $id");
	}
	$table=$table.'<p>Inserción correcta</p>';
}
else
{
	$table=$table.'<p>Esta página solo esta disponible para empleados</p><p><a href=\'login.html\'>Login</a></p>';
}
$table=$table.'
			</div>
		</div>
		<div class="Pie">
			<p>Trabajo realizado por Jose Javier Valero Fuentes y Juan Francisco Navarro Ramiro para el curso de ASIR 2º X</p>
		</div>
	</body>
</html>';
echo $table;
mysqli_close($conexion);
?>
