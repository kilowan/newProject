<?php
session_start();
?>
<?php
$table='';
$table=$table.'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
		"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>Empleado</title>
				<link rel="stylesheet" type="text/css" href="formato.css" media="screen" />
				<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			</head>
		<body>
		<div class="cabecera">
				<div class="mensaje">
					<p>Partes creados</p>
				</div>
				<div class="Logo">
					<a href="logout.php">
						<img class="cierra" src="shutdown.png" alt="Cerrar sesión" />
					</a>
				</div>
		</div>
		<div class="cuerpo">';
if (isset($_SESSION['loggedin']) && $_SESSION['tipo']=='Admin')
{
	$host_db = "localhost";
	$user_db = "Ad";
	$pass_db = "1234";
	$db_name = "Fabrica";
	$name=$_SESSION['username'];
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	$con = $conexion->query("select P.id_part, P.inf_part, P.pieza, E.nombre, E.apellido1, E.apellido2, E.id
	from parte P, Empleados E
	where P.emp_crea=E.id and resuelto='0' and P.nom_tec is null group by P.id_part, P.inf_part, E.nombre, E.id order by P.id_part asc");
	if(mysqli_num_rows($con)>0)
	{
		$table=$table.'
		<table>
			<tr>
				<th colspan="9">Partes abiertos sin atención</th>
			</tr>
			<tr>
				<th>Numero de parte</th>
				<th>Nombre de empleado</th>
				<th>Id del empleado</th>
				<th>Información del parte</th>
				<th>Pieza afectada</th>
				<th>Fecha resolución</th>
				<th>Hora resolución</th>
				<th>Técnico a cargo</th>
				<th>--</th>
			</tr>';
		
		//recorrer datos de los partes abiertos sin atender
		while($fila = mysqli_fetch_array($con, MYSQLI_ASSOC))
		{
			//insercion partes (html)
			$table=$table.'<tr><td>';
			$table=$table.$fila['id_part'];
			$id=$fila['id_part'];
			$table=$table.'</td><td>';
			$table=$table.$fila['nombre'].' '.$fila['apellido1'].' '.$fila['apellido2'];
			$table=$table.'</td><td>';
			$table=$table.$fila['id'];
			$table=$table.'</td><td>';
			$table=$table.$fila['inf_part'];
			$table=$table.'</td><td>';
			$table=$table.$fila['pieza'];
			$table=$table.'</td><td>';
			$table=$table.'--';
			$table=$table.'</td><td>';
			$table=$table.'--';
			$table=$table.'</td><td>';
			$table=$table.'--';
			$table=$table.'</td><td>';					
			$table=$table.'<form action="modparte.php" method="post">';
			$table=$table.'<input type="hidden" name="id" value="';
			$table=$table.$id;
			$table=$table.'" />';
			$table=$table.'<input type="submit" value="Ver parte" />';
			$table=$table.'</form>';
			$table=$table.'</td></tr>';
		}
		$table=$table.'</table><br />';
	}
	$con = $conexion->query("select P.id_part, P.inf_part, P.pieza, E.nombre, E.apellido1, E.apellido2, E.id, P.fecha_resolucion, P.hora_resolucion, nom_tec
	from parte P, Empleados E
	where P.emp_crea=E.id and resuelto='0' and nom_tec is not null group by P.id_part, P.inf_part, E.nombre, E.id order by P.id_part asc");
	if(mysqli_num_rows($con)>0)
	{
		$table=$table.'
		<table>
			<tr>
				<th colspan="9">Partes abiertos atendidos</th>
			</tr>
			<tr>
				<th>Numero de parte</th>
				<th>Nombre de empleado</th>
				<th>Id del empleado</th>
				<th>Información del parte</th>
				<th>Pieza afectada</th>
				<th>Fecha resolución</th>
				<th>Hora resolución</th>
				<th>Técnico a cargo</th>
				<th>--</th>
			</tr>';
		while($fila = mysqli_fetch_array($con, MYSQLI_ASSOC))
		{
			//insercion partes (html)
			$table=$table.'<tr><td>';
			$table=$table.$fila['id_part'];
			$id=$fila['id_part'];
			$table=$table.'</td><td>';
			$table=$table.$fila['nombre'].' '.$fila['apellido1'].' '.$fila['apellido2'];
			$table=$table.'</td><td>';
			$table=$table.$fila['id'];
			$table=$table.'</td><td>';
			$table=$table.$fila['inf_part'];
			$table=$table.'</td><td>';
			$table=$table.$fila['pieza'];
			$table=$table.'</td><td>';
			$table=$table.'--';
			$table=$table.'</td><td>';
			$table=$table.'--';
			$table=$table.'</td><td>';
			$table=$table.$fila['nom_tec'];
			$table=$table.'</td><td>';
			$table=$table.'<form action="modparte.php" method="post">';
			$table=$table.'<input type="hidden" name="id" value="';
			$table=$table.$id;
			$table=$table.'" />';
			$table=$table.'<input type="submit" value="Ver parte" />';
			$table=$table.'</form>';
			$table=$table.'</td></tr>';
		}
		$table=$table.'</table><br />';
	}
	$con = $conexion->query("select P.id_part, P.inf_part, P.pieza, E.nombre, E.apellido1, E.apellido2, E.id, P.fecha_resolucion, P.hora_resolucion, nom_tec
	from parte P, Empleados E
	where P.emp_crea=E.id and resuelto='1' group by P.id_part, P.inf_part, E.nombre, E.id order by P.id_part asc");
	if(mysqli_num_rows($con)>0)
	{
		$table=$table.'
				<table>
			<tr>
				<th colspan="9">Partes cerrados</th>
			</tr>
			<tr>
				<th>Numero de parte</th>
				<th>Nombre de empleado</th>
				<th>Id del empleado</th>
				<th>Información del parte</th>
				<th>Pieza afectada</th>
				<th>Fecha resolución</th>
				<th>Hora resolución</th>
				<th>Técnico a cargo</th>
				<th>--</th>
			</tr>';
		while($fila = mysqli_fetch_array($con, MYSQLI_ASSOC))
		{
			//insercion partes (html)
			$table=$table.'<tr><td>';
			$table=$table.$fila['id_part'];
			$id=$fila['id_part'];
			$table=$table.'</td><td>';
			$table=$table.$fila['nombre'].' '.$fila['apellido1'].' '.$fila['apellido2'];
			$table=$table.'</td><td>';
			$table=$table.$fila['id'];
			$table=$table.'</td><td>';
			$table=$table.$fila['inf_part'];
			$table=$table.'</td><td>';
			$table=$table.$fila['pieza'];
			$table=$table.'</td><td>';
			$table=$table.$fila['fecha_resolucion'];
			$table=$table.'</td><td>';
			$table=$table.$fila['hora_resolucion'];
			$table=$table.'</td><td>';
			$table=$table.$fila['nom_tec'];
			$table=$table.'</td><td>';
			$table=$table.'--';
			$table=$table.'</td></tr>';
		}
		$table=$table.'</table><br />';
	}
}
else
{
	$table=$table.'<div class="respuesta"><p>Esta página solo esta disponible para administradores</p><p><a href=\'login.html\'>Login</a></p></div>';
}
$table=$table.'
		</div>
		<div class="Pie">
			<p>Trabajo realizado por Jose Javier Valero Fuentes y Juan Francisco Navarro Ramiro para el curso de ASIR 2º X</p>
		</div>
	</body>
</html>';
echo $table;
mysqli_close($conexion);
?>