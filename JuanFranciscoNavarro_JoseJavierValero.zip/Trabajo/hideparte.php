<?php
session_start();
?>
<?php
$table='';
$table=$table.'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
		"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>Empleado</title>
				<LINK REL=StyleSheet HREF="formato.css" TYPE="text/css" MEDIA=screen>
				<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			</head>
		<body>
		<div class="cabecera">
				<div class="mensaje">
					<p>Parte eliminado de tu lista</p>
				</div>
				<div class="Logo">
					<a href="logout.php">
						<img class="cierra" src="shutdown.png" alt="Cerrar sesión" />
					</a>
				</div><br/>
		</div><br/>
		<div class="cuerpo">
			<div  class="respuesta">';
if (isset($_SESSION['loggedin']))
{
	$host_db = "localhost";
	$user_db = "Ad";
	$pass_db = "1234";
	$db_name = "Fabrica";
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	$id=$_POST['id'];
	//ocultar parte que cumpla condicion
	$conexion->query("update parte set oculto=1 where id_part=$id");
	$table=$table.'<p>Borrado de tu lista correctamente</p>';
}
else
{
	$table=$table.'<p>Esta página solo esta disponible para empleados</p><p><a href=\'login.html\'>Login</a></p>';
}
$table=$table.'
			</div>
		</div>
		<div class="Pie">
			<p>Trabajo realizado por Jose Javier Valero Fuentes y Juan Francisco Navarro Ramiro para el curso de ASIR 2º X</p>
		</div>
	</body>
</html>';
echo $table;
mysqli_close($conexion);
?>
