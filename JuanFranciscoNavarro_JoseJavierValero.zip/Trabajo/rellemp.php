<?php
session_start();
?>

<?php
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
		"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>Empleado creado</title>
				<link rel="stylesheet" type="text/css" href="formato.css" media="screen" />
				<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			</head>
		<body>
		<div class="cabecera">
			<div class="mensaje">
				<p>Añadiendo empleado</p>
			</div>
			<div class="Logo">
				<a href="logout.php">
					<img class="cierra" src="shutdown.png" alt="Cerrar sesión" />
				</a>
			</div>
		</div>
		<div class="cuerpo">
			<div  class="respuesta">';
if (isset($_SESSION['loggedin']))
{
	$host_db = "localhost";
	$user_db = "Ad";
	$pass_db = "1234";
	$db_name = "Fabrica";
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	$username = $_SESSION['username'];
	$dni = $_POST['dni'];
	$nom_emp = $_POST['nombre'];
	$apellido1 = $_POST['apellido1'];
	$apellido2 = $_POST['apellido2'];
	$pass = $_POST['pass'];
	$tipo = $_POST['tipo'];	
	$consulta = "insert into Empleados (dni, password, nombre, apellido1, apellido2, tipo)
	values ('$dni', MD5('$pass'), '$nom_emp', '$apellido1', '$apellido2' ,'$tipo')";
	$result2 = $conexion->query($consulta);
	echo '<p class="respuesta">Empleado añadido satisfactoriamente</p>';
}
else
{
	echo '<p>Esta página solo esta disponible para empleados</p>';
	echo '<p><a href="login.html">Login</a></p>';
}
echo '
			</div>
		</div>
		<div class="Pie">
			<p>Trabajo realizado por Jose Javier Valero Fuentes y Juan Francisco Navarro Ramiro para el curso de ASIR 2º X</p>
		</div>
	</body>
</html>';
mysqli_close($conexion);
?>