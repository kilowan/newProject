<?php
session_start();
?>

<?php
$table='';
$table=$table.'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
		"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>Ver parte</title>
				<LINK REL=StyleSheet HREF="formato.css" TYPE="text/css" MEDIA=screen>
				<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			</head>
		<body>
		<div class="cabecera">
			<div class="mensaje">
				<p>Modificando o cerrando parte</p>
			</div>
			<div class="Logo">
				<a href="logout.php">
					<img class="cierra" src="shutdown.png" alt="Cerrar sesión" />
				</a>
			</div><br/>
		</div><br/>
		<div class="cuerpo">';
if (isset($_SESSION['loggedin']))
{
	$host_db = "localhost";
	$user_db = "Ad";
	$pass_db = "1234";
	$db_name = "Fabrica";
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	$id=$_POST['id'];
	//extraer datos parte
	$con = $conexion->query("select E.nombre, P.not_tec, P.inf_part, P.pieza, P.fecha_hora_creacion from Empleados E, parte P where 
	E.id=P.emp_crea and id_part=$id");
	//imprime datos del parte
	while($fila = mysqli_fetch_array($con, MYSQLI_ASSOC))
	{
		$table=$table.'<div class="mod_parte"><p>Formulario de edición</p>';
		$table=$table.'<p>Nombre del empleado: <strong>';
		$table=$table.$fila['nombre'];
		$table=$table.'</strong></p><p>Información del parte: <strong>';
		$table=$table.$fila['inf_part'];
		$table=$table.'</strong></p><p>Pieza afectada: <strong>';
		$table=$table.$fila['pieza'];
		$table=$table.'</strong></p><p>Fecha de creacion: <strong>';
		$table=$table.$fila['fecha_hora_creacion'];
		$table=$table.'</strong></p><p>Notas anteriores: <strong>';
		$table=$table.$fila['not_tec'];
		$table=$table.'</strong></p><form action="" method="post">';
		$table=$table.'<label>Notas de resolución:</label><br/>';
		$table=$table.'<textarea name="not_tec" rows="2" cols="40" required></textarea><br/>';
		$table=$table.'<p>Piezas afectadas:</p>
						<p> 
						<select name="piezas">
							<option value="--" selectted="selected">--</option>
							<optgroup label="Sobre la torre">
								<option value="torre">La torre</option>
								<option value="Placa base">La placa base</option>
								<option value="HDD">El disco duro</option>
								<option value="procesador">El procesador</option>
								<option value="grafica">La grafica</option>
								<option value="RAM">La memoria RAM</option>
								<option value="lector">El lector</option>
							</optgroup>
							<optgroup label="perifericos">
								<option value="pantalla">El monitor o proyector</option>
								<option value="raton">El raton</option>
								<option value="teclado">El teclado</option>
								<option value="impresora">La impresora</option>
							</optgroup>
						<optgroup label="otros">
							 <option value="regleta">La regleta</option>
							 <option value="Router">El router</option>
						</optgroup>
						</select>
					</p>';
		$table=$table.'<input type="hidden" name="id" value="';
		$table=$table.$id;
		$table=$table.'" />';
		$table=$table.'<input type="submit" name="Editar parte" value="Editar parte" onclick=this.form.action="insertparte.php">';
		$table=$table.'<input type="submit" name="Cerrar parte" value="Cerrar parte" onclick=this.form.action="cierraparte.php">';
		$table=$table.'</form></div>';
		$table=$table.'</table><br />';
	}	
}
else
{
	$table=$table.'<div class="respuesta"><p>Esta página solo esta disponible para empleados</p><p><a href=\'login.html\'>Login</a></p></div>';
}
$table=$table.'
		</div>
		<div class="Pie">
			<p>Trabajo realizado por Jose Javier Valero Fuentes y Juan Francisco Navarro Ramiro para el curso de ASIR 2º X</p>
		</div>
	</body>
</html>';
echo $table;
mysqli_close($conexion);
?>
